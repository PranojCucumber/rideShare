import java.io.*;

public class SafeFileReader {
    public static void main(String[] args) {
        String filePath = "example.txt";
        readFileSafely(filePath);
    }

    public static void readFileSafely(String filePath) {
        File file = new File(filePath);
        
        // Check if file exists before attempting to read
        if (!file.exists()) {
            System.err.println("Error: File not found - " + filePath);
            return; // Fails safely without proceeding
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
    }
}
